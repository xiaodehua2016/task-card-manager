/**
 * 跨浏览器数据同步解决方案 v4.2.5
 * 通过服务器端文件实现数据共享
 * 增强日志记录，修复同步问题
 */

class CrossBrowserSync {
    constructor() {
        this.syncEndpoint = 'api/data-sync.php';
        this.syncInterval = 3000; // 3秒同步一次，提高同步频率
        this.lastSyncTime = 0;
        this.isOnline = navigator.onLine;
        this.syncTimer = null;
        
        this.init();
    }

    init() {
        // 监听网络状态
        window.addEventListener('online', () => {
            this.isOnline = true;
            this.startSync();
            console.log('📶 网络已连接，启动同步');
        });
        
        window.addEventListener('offline', () => {
            this.isOnline = false;
            this.stopSync();
            console.log('📶 网络已断开，停止同步');
        });

        // 页面可见时立即同步
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && this.isOnline) {
                console.log('👁️ 页面变为可见，立即同步');
                this.syncNow();
            }
        });

        // 启动定期同步
        this.startSync();
    }

    // 启动同步
    startSync() {
        if (this.syncTimer) {
            clearInterval(this.syncTimer);
        }

        this.syncTimer = setInterval(() => {
            this.syncNow();
        }, this.syncInterval);

        // 立即执行一次同步
        this.syncNow();
        console.log(`🔄 启动定期同步，间隔: ${this.syncInterval}ms`);
    }

    // 停止同步
    stopSync() {
        if (this.syncTimer) {
            clearInterval(this.syncTimer);
            this.syncTimer = null;
            console.log('⏹️ 停止同步');
        }
    }

    // 立即同步
    async syncNow() {
        if (!this.isOnline) {
            console.log('📶 网络离线，跳过同步');
            return;
        }

        try {
            console.log('🔄 开始同步数据...');
            const localData = this.getLocalData();
            console.log('📤 本地数据:', localData ? '有效' : '无效', localData ? `(更新时间: ${new Date(localData.lastUpdateTime).toLocaleString()})` : '');
            
            const serverData = await this.fetchServerData();
            console.log('📥 服务器数据:', serverData ? '有效' : '无效', serverData ? `(更新时间: ${new Date(serverData.lastUpdateTime).toLocaleString()})` : '');
            
            if (this.needsSync(localData, serverData)) {
                console.log('🔄 需要同步，合并数据...');
                const mergedData = this.mergeData(localData, serverData);
                console.log('📤 保存合并数据到服务器...');
                const saveResult = await this.saveToServer(mergedData);
                console.log('💾 服务器保存结果:', saveResult);
                
                console.log('💾 保存合并数据到本地...');
                this.saveToLocal(mergedData);
                this.notifyDataUpdate();
                console.log('✅ 同步完成');
            } else {
                console.log('✅ 数据已同步，无需更新');
            }
        } catch (error) {
            console.warn('❌ 同步失败，使用本地数据:', error.message);
            console.error('同步错误详情:', error);
            // 同步失败时不影响本地功能
        }
    }

    // 获取本地数据
    getLocalData() {
        try {
            const data = localStorage.getItem('taskManagerData');
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error('❌ 读取本地数据失败:', error);
            return null;
        }
    }

    // 获取服务器数据
    async fetchServerData() {
        console.log(`🌐 请求服务器数据: ${this.syncEndpoint}`);
        const startTime = Date.now();
        
        try {
            // 添加时间戳防止缓存
            const url = this.syncEndpoint + (this.syncEndpoint.includes('?') ? '&' : '?') + 't=' + Date.now();
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                cache: 'no-cache' // 禁用缓存，确保获取最新数据
            });
            
            const endTime = Date.now();
            console.log(`🌐 服务器响应: ${response.status} ${response.statusText} (${endTime - startTime}ms)`);

            if (!response.ok) {
                throw new Error(`服务器响应错误: ${response.status}`);
            }

            const responseText = await response.text();
            console.log(`🌐 服务器响应内容: ${responseText.substring(0, 100)}...`);
            
            try {
                // 检查响应是否为空
                if (!responseText.trim()) {
                    console.warn('⚠️ 服务器返回空响应');
                    return null;
                }
                
                // 检查响应是否以 < 开头 (可能是HTML)
                if (responseText.trim().startsWith('<')) {
                    console.error('❌ 服务器返回了HTML而不是JSON');
                    console.log('❌ 响应内容:', responseText);
                    throw new Error('服务器返回了HTML而不是JSON');
                }
                
                return JSON.parse(responseText);
            } catch (parseError) {
                console.error('❌ 解析服务器响应失败:', parseError);
                console.log('❌ 响应内容:', responseText);
                throw new Error(`解析服务器响应失败: ${parseError.message}`);
            }
        } catch (error) {
            console.error('❌ 获取服务器数据失败:', error);
            throw error;
        }
    }

    // 判断是否需要同步
    needsSync(localData, serverData) {
        if (!localData && !serverData) {
            console.log('🔄 本地和服务器都没有数据，无需同步');
            return false;
        }
        if (!localData || !serverData) {
            console.log('🔄 本地或服务器缺少数据，需要同步');
            return true;
        }
        
        const localTime = localData.lastUpdateTime || 0;
        const serverTime = serverData.lastUpdateTime || 0;
        
        const timeDiff = Math.abs(localTime - serverTime);
        console.log(`🔄 时间差异: ${timeDiff}ms (本地: ${localTime}, 服务器: ${serverTime})`);
        
        return timeDiff > 500; // 0.5秒差异就同步，提高敏感度
    }

    // 合并数据
    mergeData(localData, serverData) {
        if (!localData) {
            console.log('🔄 使用服务器数据 (本地无数据)');
            return serverData;
        }
        if (!serverData) {
            console.log('🔄 使用本地数据 (服务器无数据)');
            return localData;
        }

        const localTime = localData.lastUpdateTime || 0;
        const serverTime = serverData.lastUpdateTime || 0;

        // 使用最新的数据
        if (localTime > serverTime) {
            console.log(`🔄 使用本地数据 (本地更新: ${new Date(localTime).toLocaleString()})`);
            return { ...localData, lastUpdateTime: Date.now() };
        } else {
            console.log(`🔄 使用服务器数据 (服务器更新: ${new Date(serverTime).toLocaleString()})`);
            return { ...serverData, lastUpdateTime: Date.now() };
        }
    }

    // 保存到服务器
    async saveToServer(data) {
        console.log(`🌐 保存数据到服务器: ${this.syncEndpoint}`);
        const startTime = Date.now();
        
        try {
            const response = await fetch(this.syncEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            const endTime = Date.now();
            console.log(`🌐 服务器响应: ${response.status} ${response.statusText} (${endTime - startTime}ms)`);

            if (!response.ok) {
                throw new Error(`保存到服务器失败: ${response.status}`);
            }

            const responseText = await response.text();
            console.log(`🌐 服务器响应内容: ${responseText.substring(0, 100)}...`);
            
            try {
                return JSON.parse(responseText);
            } catch (parseError) {
                console.error('❌ 解析服务器响应失败:', parseError);
                console.log('❌ 响应内容:', responseText);
                throw new Error(`解析服务器响应失败: ${parseError.message}`);
            }
        } catch (error) {
            console.error('❌ 保存到服务器失败:', error);
            throw error;
        }
    }

    // 保存到本地
    saveToLocal(data) {
        try {
            localStorage.setItem('taskManagerData', JSON.stringify(data));
            this.lastSyncTime = Date.now();
            console.log(`💾 数据已保存到本地 (${new Date().toLocaleString()})`);
        } catch (error) {
            console.error('❌ 保存到本地失败:', error);
        }
    }

    // 通知数据更新
    notifyDataUpdate() {
        window.dispatchEvent(new CustomEvent('crossBrowserDataSync', {
            detail: { timestamp: Date.now() }
        }));
        console.log('📢 已发送数据更新通知');
    }

    // 手动触发同步
    forcSync() {
        console.log('🔄 手动触发同步');
        return this.syncNow();
    }
}

// 增强版本：基于API的数据共享
class SimpleFileSync {
    constructor() {
        this.syncEndpoint = 'api/data-sync.php';
        this.checkInterval = 2000; // 2秒检查一次，提高同步频率
        this.lastCheckTime = 0;
        this.isChecking = false;
        this.retryCount = 0;
        this.maxRetries = 5; // 增加重试次数
        this.storageKey = 'taskManagerData';
        this.version = '4.2.5'; // 更新版本号
        this.debugMode = true; // 启用调试模式
        
        this.init();
    }

    init() {
        this.log('🚀 初始化同步系统 v' + this.version);
        
        // 页面可见时检查数据
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                this.log('👁️ 页面变为可见，检查数据同步');
                this.checkForUpdates();
            }
        });

        // 定期检查
        setInterval(() => {
            this.checkForUpdates();
        }, this.checkInterval);

        // 启动存储监听器
        this.startStorageListener();

        // 页面获得焦点时检查
        window.addEventListener('focus', () => {
            this.log('🔍 页面获得焦点，检查数据同步');
            this.checkForUpdates();
        });

        // 立即检查一次
        setTimeout(() => {
            this.checkForUpdates();
        }, 500); // 更快地进行初始同步
    }

    // 日志函数
    log(message, data) {
        if (this.debugMode) {
            const timestamp = new Date().toLocaleTimeString();
            if (data) {
                console.log(`[${timestamp}] ${message}`, data);
            } else {
                console.log(`[${timestamp}] ${message}`);
            }
        }
    }

    // 错误日志
    error(message, error) {
        const timestamp = new Date().toLocaleTimeString();
        console.error(`[${timestamp}] ❌ ${message}`, error);
    }

    // 检查数据更新
    async checkForUpdates() {
        if (this.isChecking) {
            this.log('⏳ 已有同步进行中，跳过');
            return;
        }
        
        this.isChecking = true;
        this.log('🔄 开始检查数据更新...');

        try {
            // 添加时间戳防止缓存
            const url = this.syncEndpoint + (this.syncEndpoint.includes('?') ? '&' : '?') + 't=' + Date.now();
            this.log(`🌐 请求服务器数据: ${url}`);
            
            const startTime = Date.now();
            const response = await fetch(url, {
                method: 'GET',
                cache: 'no-cache',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            });
            
            const endTime = Date.now();
            this.log(`🌐 服务器响应: ${response.status} ${response.statusText} (${endTime - startTime}ms)`);

            if (response.ok) {
                const responseText = await response.text();
                this.log(`🌐 服务器响应内容: ${responseText.substring(0, 100)}...`);
                
                // 检查响应是否为空
                if (!responseText.trim()) {
                    this.log('⚠️ 服务器返回空响应');
                    this.isChecking = false;
                    return;
                }
                
                // 检查响应是否以 < 开头 (可能是HTML)
                if (responseText.trim().startsWith('<')) {
                    this.error('❌ 服务器返回了HTML而不是JSON');
                    this.log('❌ 响应内容:', responseText.substring(0, 100));
                    this.handleSyncError();
                    this.isChecking = false;
                    return;
                }
                
                try {
                    const responseData = JSON.parse(responseText);
                    this.log('📥 解析服务器响应成功:', responseData);
                    
                    if (responseData.success && responseData.data) {
                        const serverData = responseData.data;
                        const localData = this.getLocalData();
                        
                        this.log('📤 本地数据:', localData ? '有效' : '无效', localData ? `(更新时间: ${new Date(localData.lastUpdateTime).toLocaleString()})` : '');
                        this.log('📥 服务器数据:', `(更新时间: ${new Date(serverData.lastUpdateTime || serverData.serverUpdateTime).toLocaleString()})`);
                        
                        if (this.shouldUpdate(localData, serverData)) {
                            this.log('🔄 需要更新，合并数据...');
                            // 合并数据而不是直接覆盖
                            const mergedData = this.mergeData(localData, serverData);
                            this.updateLocalData(mergedData);
                            this.notifyUpdate();
                            this.log('✅ 从服务器更新了数据');
                            this.retryCount = 0; // 重置重试计数
                        } else {
                            this.log('✅ 本地数据已是最新，无需更新');
                            // 即使不需要更新，也确保本地数据有最新的时间戳
                            this.updateTimestamp(localData);
                        }
                    } else if (responseData.success && !responseData.data) {
                        // 服务器没有数据，上传本地数据
                        const localData = this.getLocalData();
                        if (localData) {
                            this.log('📤 服务器无数据，上传本地数据');
                            await this.saveToServer(localData);
                        } else {
                            this.log('⚠️ 本地和服务器都没有数据');
                        }
                    } else {
                        this.log('⚠️ 服务器响应无效:', responseData);
                    }
                } catch (parseError) {
                    this.error('解析服务器响应失败:', parseError);
                    this.log('❌ 响应内容:', responseText);
                    this.handleSyncError();
                }
            } else {
                this.error(`服务器响应错误: ${response.status}`, await response.text());
                this.handleSyncError();
            }
        } catch (error) {
            this.error('数据同步失败:', error);
            this.handleSyncError();
        } finally {
            this.isChecking = false;
        }
    }
    
    // 更新时间戳
    updateTimestamp(data) {
        if (!data) return;
        
        try {
            data.lastUpdateTime = Date.now();
            localStorage.setItem(this.storageKey, JSON.stringify(data));
            this.log('🕒 更新了本地数据时间戳');
        } catch (error) {
            this.error('更新时间戳失败:', error);
        }
    }
    
    // 处理同步错误
    handleSyncError() {
        this.retryCount++;
        if (this.retryCount <= this.maxRetries) {
            this.log(`⚠️ 使用本地数据模式 (重试 ${this.retryCount}/${this.maxRetries})`);
            // 如果是第一次失败，尝试保存本地数据到服务器
            if (this.retryCount === 1) {
                const localData = this.getLocalData();
                if (localData) {
                    setTimeout(() => {
                        this.log('🔄 尝试重新保存本地数据到服务器');
                        this.saveToServer(localData).catch(err => 
                            this.error('保存到服务器失败:', err)
                        );
                    }, 1000);
                }
            }
        } else {
            this.error('数据同步失败次数过多，请检查网络连接或服务器状态');
            // 重置重试计数，避免永久阻塞
            setTimeout(() => {
                this.retryCount = 0;
                this.log('🔄 重置重试计数');
            }, 30000); // 30秒后重置
        }
    }

    // 获取本地数据
    getLocalData() {
        try {
            // 尝试多个可能的存储键
            const keys = ['taskManagerData', 'xiaojiu_tasks', 'tasks'];
            
            for (const key of keys) {
                const data = localStorage.getItem(key);
                if (data) {
                    try {
                        const parsed = JSON.parse(data);
                        if (parsed && (parsed.tasks || parsed.dailyTasks || parsed.completionHistory)) {
                            // 标准化数据格式
                            this.log(`📂 从存储键 "${key}" 找到有效数据`);
                            return this.normalizeData(parsed, key);
                        }
                    } catch (parseError) {
                        this.error(`解析 ${key} 数据失败:`, parseError);
                        // 继续尝试其他键
                    }
                }
            }
            this.log('⚠️ 未找到本地数据');
            return null;
        } catch (error) {
            this.error('获取本地数据失败:', error);
            return null;
        }
    }

    // 标准化数据格式
    normalizeData(data, sourceKey) {
        this.log('🔄 标准化数据格式，来源:', sourceKey);
        
        const normalized = {
            version: this.version, // 使用当前版本号
            lastUpdateTime: data.lastUpdateTime || Date.now(),
            serverUpdateTime: data.serverUpdateTime || 0,
            username: data.username || '小久',
            tasks: data.tasks || [],
            taskTemplates: data.taskTemplates || { daily: [] },
            dailyTasks: data.dailyTasks || {},
            completionHistory: data.completionHistory || {},
            taskTimes: data.taskTimes || {},
            focusRecords: data.focusRecords || {},
            sourceKey: sourceKey // 记录数据来源
        };
        
        return normalized;
    }

    // 合并数据 - 增强版
    mergeData(localData, serverData) {
        if (!localData) {
            this.log('📥 使用服务器数据 (本地无数据)');
            return serverData;
        }
        if (!serverData) {
            this.log('📤 使用本地数据 (服务器无数据)');
            return localData;
        }

        const localTime = localData.lastUpdateTime || 0;
        const serverTime = serverData.serverUpdateTime || serverData.lastUpdateTime || 0;

        // 创建合并后的数据对象
        const mergedData = {
            version: this.version,
            lastUpdateTime: Date.now(),
            serverUpdateTime: Date.now(),
            username: localData.username || serverData.username || '小久',
            tasks: [],
            taskTemplates: { daily: [] },
            dailyTasks: {},
            completionHistory: {},
            taskTimes: {},
            focusRecords: {}
        };

        // 如果服务器数据更新，优先使用服务器数据
        if (serverTime > localTime) {
            this.log(`🔄 优先使用服务器数据 (更新) - 服务器时间: ${new Date(serverTime).toLocaleString()}, 本地时间: ${new Date(localTime).toLocaleString()}`);
            Object.assign(mergedData, serverData);
        } 
        // 如果本地数据更新，优先使用本地数据
        else if (localTime > serverTime) {
            this.log(`🔄 优先使用本地数据 (更新) - 本地时间: ${new Date(localTime).toLocaleString()}, 服务器时间: ${new Date(serverTime).toLocaleString()}`);
            Object.assign(mergedData, localData);
        }
        // 时间相同，智能合并数据
        else {
            this.log('🔄 智能合并本地和服务器数据 (时间相同)');
            
            // 合并任务列表 - 取并集
            mergedData.tasks = this.mergeArrays(localData.tasks, serverData.tasks);
            this.log(`📊 合并任务列表: 本地(${localData.tasks?.length || 0}) + 服务器(${serverData.tasks?.length || 0}) = 合并后(${mergedData.tasks.length})`);
            
            // 合并任务模板
            mergedData.taskTemplates = this.mergeTaskTemplates(localData.taskTemplates, serverData.taskTemplates);
            
            // 合并每日任务 - 按日期取最新
            mergedData.dailyTasks = this.mergeDailyTasks(localData.dailyTasks, serverData.dailyTasks);
            
            // 合并完成历史 - 按日期取并集
            mergedData.completionHistory = this.mergeCompletionHistory(localData.completionHistory, serverData.completionHistory);
            
            // 合并任务时间 - 取最大值
            mergedData.taskTimes = this.mergeTaskTimes(localData.taskTimes, serverData.taskTimes);
            
            // 合并专注记录 - 按ID取并集
            mergedData.focusRecords = this.mergeFocusRecords(localData.focusRecords, serverData.focusRecords);
        }
        
        return mergedData;
    }
    
    // 合并数组，去重
    mergeArrays(arr1 = [], arr2 = []) {
        // 使用Map来去重，保留对象的完整性
        const map = new Map();
        
        // 添加第一个数组的元素
        arr1.forEach(item => {
            const id = item.id || JSON.stringify(item);
            map.set(id, item);
        });
        
        // 添加第二个数组的元素，如果有相同ID则覆盖
        arr2.forEach(item => {
            const id = item.id || JSON.stringify(item);
            map.set(id, item);
        });
        
        return Array.from(map.values());
    }
    
    // 合并任务模板
    mergeTaskTemplates(templates1 = {}, templates2 = {}) {
        const result = { ...templates1 };
        
        // 合并每种类型的模板
        for (const type in templates2) {
            if (result[type]) {
                result[type] = this.mergeArrays(result[type], templates2[type]);
            } else {
                result[type] = [...templates2[type]];
            }
        }
        
        return result;
    }
    
    // 合并每日任务
    mergeDailyTasks(tasks1 = {}, tasks2 = {}) {
        const result = { ...tasks1 };
        
        // 对每个日期，取最新的任务列表
        for (const date in tasks2) {
            if (!result[date] || 
                (tasks2[date].lastUpdated && (!result[date].lastUpdated || tasks2[date].lastUpdated > result[date].lastUpdated))) {
                result[date] = tasks2[date];
            }
        }
        
        return result;
    }
    
    // 合并完成历史
    mergeCompletionHistory(history1 = {}, history2 = {}) {
        const result = { ...history1 };
        
        // 对每个日期，合并完成状态
        for (const date in history2) {
            if (!result[date]) {
                result[date] = history2[date];
            } else {
                // 如果两边都有，取并集（任何一边标记为完成的都算完成）
                for (let i = 0; i < history2[date].length; i++) {
                    if (i < result[date].length) {
                        result[date][i] = result[date][i] || history2[date][i];
                    } else {
                        result[date].push(history2[date][i]);
                    }
                }
            }
        }
        
        return result;
    }
    
    // 合并任务时间
    mergeTaskTimes(times1 = {}, times2 = {}) {
        const result = { ...times1 };
        
        // 对每个任务，取最大时间
        for (const task in times2) {
            if (!result[task] || times2[task] > result[task]) {
                result[task] = times2[task];
            }
        }
        
        return result;
    }
    
    // 合并专注记录
    mergeFocusRecords(records1 = {}, records2 = {}) {
        const result = { ...records1 };
        
        // 合并所有记录
        for (const id in records2) {
            if (!result[id]) {
                result[id] = records2[id];
            }
        }
        
        return result;
    }

    // 判断是否应该更新
    shouldUpdate(localData, serverData) {
        if (!localData) {
            this.log('🔄 本地无数据，需要从服务器更新');
            return !!serverData;
        }
        if (!serverData) {
            this.log('🔄 服务器无数据，无需更新');
            return false;
        }
        
        const localTime = localData.lastUpdateTime || 0;
        const serverTime = serverData.lastUpdateTime || 0;
        const serverUpdateTime = serverData.serverUpdateTime || 0;
        
        this.log(`🕒 时间比较 - 本地: ${new Date(localTime).toLocaleString()}, 服务器: ${new Date(serverTime).toLocaleString()}, 服务器更新: ${new Date(serverUpdateTime).toLocaleString()}`);
        
        // 如果服务器时间比本地时间新，或者服务器有serverUpdateTime且比本地新
        const shouldUpdate = serverTime > localTime || serverUpdateTime > localTime;
        this.log(`🔄 是否需要更新: ${shouldUpdate ? '是' : '否'}`);
        return shouldUpdate;
    }

    // 更新本地数据
    updateLocalData(data) {
        try {
            // 保存到主要存储键
            localStorage.setItem(this.storageKey, JSON.stringify(data));
            
            // 如果数据有来源键，也更新原来的存储位置
            if (data.sourceKey && data.sourceKey !== this.storageKey) {
                localStorage.setItem(data.sourceKey, JSON.stringify(data));
                this.log(`💾 同时更新了原始存储键: ${data.sourceKey}`);
            }
            
            this.log('💾 本地数据已更新');
        } catch (error) {
            this.error('更新本地数据失败:', error);
        }
    }

    // 通知更新
    notifyUpdate() {
        window.dispatchEvent(new CustomEvent('dataUpdatedFromServer', {
            detail: { timestamp: Date.now() }
        }));
        this.log('📢 已发送数据更新通知');
    }

    // 保存数据到服务器
    async saveToServer(data) {
        try {
            // 确保数据有最新的时间戳
            data.lastUpdateTime = Date.now();
            data.serverUpdateTime = Date.now();
            data.version = this.version; // 确保版本号正确
            
            this.log(`📤 保存数据到服务器: ${this.syncEndpoint}`);
            this.log('📤 数据内容:', {
                version: data.version,
                lastUpdateTime: new Date(data.lastUpdateTime).toLocaleString(),
                serverUpdateTime: new Date(data.serverUpdateTime).toLocaleString(),
                tasksCount: data.tasks?.length || 0
            });
            
            const startTime = Date.now();
            const response = await fetch(this.syncEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            const endTime = Date.now();
            this.log(`🌐 服务器响应: ${response.status} ${response.statusText} (${endTime - startTime}ms)`);
            
            if (response.ok) {
                const responseText = await response.text();
                this.log(`🌐 服务器响应内容: ${responseText.substring(0, 100)}...`);
                
                try {
                    const result = JSON.parse(responseText);
                    if (result.success) {
                        this.log('✅ 数据已保存到服务器:', result.message);
                        this.retryCount = 0; // 重置重试计数
                        return true;
                    } else {
                        this.error('保存到服务器失败:', result.message);
                        return false;
                    }
                } catch (parseError) {
                    this.error('解析服务器响应失败:', parseError);
                    this.log('❌ 响应内容:', responseText);
                    return false;
                }
            } else {
                this.error(`保存到服务器失败: HTTP ${response.status}`, await response.text());
                return false;
            }
        } catch (error) {
            this.error('保存到服务器失败:', error);
            return false;
        }
    }

    // 监听本地存储变化并自动同步
    startStorageListener() {
        // 监听localStorage变化
        const originalSetItem = localStorage.setItem;
        const self = this;
        
        localStorage.setItem = function(key, value) {
            originalSetItem.apply(this, arguments);
            
            // 如果是任务数据变化，触发同步
            if (key === 'taskManagerData' || key === 'xiaojiu_tasks' || key === 'tasks') {
                self.log('🔄 检测到本地数据变化，准备同步');
                setTimeout(() => {
                    self.checkForUpdates();
                }, 300); // 更快地响应变化
            }
        };
    }

    // 强制同步数据
    async forceSync() {
        this.log('🔄 开始强制同步...');
        
        try {
            const localData = this.getLocalData();
            if (!localData) {
                this.log('❌ 没有本地数据可同步');
                return false;
            }

            // 先尝试从服务器获取数据
            const response = await fetch(this.syncEndpoint + '?t=' + Date.now(), {
                method: 'GET',
                cache: 'no-cache'
            });

            if (response.ok) {
                const responseText = await response.text();
                this.log(`🌐 服务器响应内容: ${responseText.substring(0, 100)}...`);
                
                try {
                    const responseData = JSON.parse(responseText);
                    
                    if (responseData.success && responseData.data) {
                        // 合并数据
                        const serverData = responseData.data;
                        this.log('📥 获取到服务器数据，准备合并');
                        const mergedData = this.mergeData(localData, serverData);
                        
                        // 保存合并后的数据到服务器
                        this.log('📤 保存合并数据到服务器');
                        const saveSuccess = await this.saveToServer(mergedData);
                        if (saveSuccess) {
                            // 更新本地数据
                            this.log('💾 更新本地数据');
                            this.updateLocalData(mergedData);
                            this.notifyUpdate();
                            this.log('✅ 强制同步成功');
                            return true;
                        } else {
                            this.error('保存合并数据到服务器失败');
                        }
                    } else {
                        // 服务器没有数据，直接上传本地数据
                        this.log('📤 服务器无数据，直接上传本地数据');
                        const saveSuccess = await this.saveToServer(localData);
                        if (saveSuccess) {
                            this.log('✅ 本地数据已上传到服务器');
                            return true;
                        } else {
                            this.error('上传本地数据到服务器失败');
                        }
                    }
                } catch (parseError) {
                    this.error('解析服务器响应失败:', parseError);
                    this.log('❌ 响应内容:', responseText);
                }
            } else {
                this.error(`服务器响应错误: ${response.status}`, await response.text());
            }
            
            this.log('❌ 强制同步失败');
            return false;
            
        } catch (error) {
            this.error('强制同步出错:', error);
            return false;
        }
    }
}

// 创建数据同步实例
window.dataSyncManager = new SimpleFileSync();

// 监听数据更新事件
window.addEventListener('dataUpdatedFromServer', () => {
    console.log('🔄 检测到服务器数据更新');
    if (window.taskManager) {
        window.taskManager.refreshAllData();
    }
});

// 监听本地数据变化，自动同步到服务器
window.addEventListener('storage', (e) => {
    if (e.key === 'taskManagerData' && e.newValue) {
        console.log('🔄 检测到本地数据变化，准备同步到服务器');
        setTimeout(() => {
            if (window.dataSyncManager) {
                const localData = window.dataSyncManager.getLocalData();
                if (localData) {
                    window.dataSyncManager.saveToServer(localData);
                }
            }
        }, 500); // 更快地响应变化
    }
});

// 页面获得焦点时立即检查同步
window.addEventListener('focus', () => {
    if (window.dataSyncManager) {
        console.log('🔄 页面获得焦点，检查数据同步');
        window.dataSyncManager.checkForUpdates();
    }
});

console.log('跨浏览器数据同步 v4.2.5 已启动');
